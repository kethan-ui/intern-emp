# Employee Management System — CRUD Full-Stack App

A full-featured CRUD web application built for **Task 2: CRUD Employee Management System**
(WeIntern Pvt Ltd — Full Stack Development, Week 2).

**Live demo:** _add your deployed link here, if hosted (e.g. Render/Railway for the backend)_

## Project purpose

Let an HR admin add, view, search, sort, edit, and delete employee records through a clean
web interface backed by a real database and REST API — the four CRUD operations end to end.

## Tech stack

| Layer      | Choice                                   |
|------------|-------------------------------------------|
| Frontend   | HTML5, CSS3, vanilla JavaScript (fetch API) |
| Backend    | Node.js + Express 5                       |
| Database   | SQLite via `better-sqlite3` (file-based, zero setup) |
| API testing| Postman collection included               |

**Why SQLite instead of MySQL/PostgreSQL/MongoDB:** it's a genuine relational database with
real SQL and a schema (see `backend/db/database.js`), but it needs no separate server
process or install — the whole app runs with one `npm install && npm start`. Swapping to
MySQL/Postgres later only means changing the `db/database.js` connection layer; the routes
and frontend don't need to change.

## Features

- **Create** — "Add Employee" modal with client + server-side validation
- **Read** — data table with all employees, badge-styled department column
- **Search** — live search across name, department, and role (debounced, server-side)
- **Sort** — click any column header to sort asc/desc (server-side, via query params)
- **Update** — "Edit" opens the same modal pre-filled with existing data
- **Delete** — confirmation modal before removal (no accidental deletes)
- Loading, empty, and error states in the table
- Toast notifications for success/failure feedback

## API endpoints

| Method | Endpoint                | Description                          |
|--------|--------------------------|---------------------------------------|
| GET    | `/api/employees`         | List employees. Query params: `search`, `sortBy` (name/department/role/salary/join_date), `order` (asc/desc) |
| GET    | `/api/employees/:id`     | Get one employee                      |
| POST   | `/api/employees`         | Create an employee                    |
| PUT    | `/api/employees/:id`     | Update an employee                    |
| DELETE | `/api/employees/:id`     | Delete an employee                    |
| GET    | `/api/health`            | Health check                          |

A Postman collection covering all of these is at `postman/employees.postman_collection.json`
— import it and set the `baseUrl` variable if needed.

## Database schema

```sql
CREATE TABLE employees (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  department  TEXT NOT NULL,
  role        TEXT NOT NULL,
  salary      REAL NOT NULL,
  join_date   TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
```

The schema is created automatically on first run (`backend/db/database.js`), along with six
seed records so the table isn't empty on first load.

## File structure

```
employee-management-system/
├── backend/
│   ├── server.js            Express app entry point (serves API + static frontend)
│   ├── package.json
│   ├── db/
│   │   └── database.js      SQLite schema + seed data
│   ├── routes/
│   │   └── employees.js     CRUD route handlers + validation
│   └── data/
│       └── employees.db     SQLite file (created on first run — gitignored)
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js            fetch()-based API integration
├── postman/
│   └── employees.postman_collection.json
├── screenshots/
└── README.md
```

## Setup / run instructions

```bash
cd backend
npm install
npm start
```

Then open **http://localhost:4000** — the Express server serves both the API and the
frontend, so there's nothing else to run. The SQLite database file is created automatically
at `backend/data/employees.db` on first launch, with six seed employees.

To reset the data, stop the server and delete `backend/data/employees.db` (and the `-wal`/
`-shm` files if present), then restart.

## Testing the API directly

```bash
curl http://localhost:4000/api/employees
curl -X POST http://localhost:4000/api/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Jamie Rivera","department":"Engineering","role":"QA Engineer","salary":62000,"join_date":"2026-09-01"}'
```

Or import `postman/employees.postman_collection.json` into Postman/Thunder Client.

## Before submitting

- [ ] Record a short screen capture or add screenshots of each CRUD operation
- [ ] If deploying, host the backend (Render/Railway/Fly.io) since it needs a Node process —
      static hosts like GitHub Pages won't run the API
- [ ] Update the live demo link above
