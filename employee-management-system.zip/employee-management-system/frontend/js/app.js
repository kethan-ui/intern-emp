// js/app.js
// Vanilla JS frontend for the Employee Management System.
// Talks to the Express REST API via fetch().

(function () {
  "use strict";

  const API_BASE = "/api/employees";

  const state = {
    employees: [],
    search: "",
    sortBy: "name",
    order: "asc",
    loading: false,
    error: null,
  };

  // ---- DOM refs ----
  const tbody = document.getElementById("employee-table-body");
  const tableStatus = document.getElementById("table-status");
  const searchInput = document.getElementById("search-input");
  const addBtn = document.getElementById("add-employee-btn");
  const headerCells = document.querySelectorAll("thead th[data-sort]");

  const modalOverlay = document.getElementById("employee-modal-overlay");
  const modalTitle = document.getElementById("employee-modal-title");
  const form = document.getElementById("employee-form");
  const cancelFormBtn = document.getElementById("cancel-form-btn");
  const employeeIdField = document.getElementById("employee-id");

  const confirmOverlay = document.getElementById("confirm-modal-overlay");
  const confirmPreview = document.getElementById("confirm-employee-preview");
  const confirmDeleteBtn = document.getElementById("confirm-delete-btn");
  const cancelDeleteBtn = document.getElementById("cancel-delete-btn");

  const toast = document.getElementById("toast");
  let pendingDeleteId = null;

  // ---- Helpers ----
  function money(n) {
    return "$" + Number(n).toLocaleString("en-US");
  }

  function showToast(message, isError) {
    toast.textContent = message;
    toast.classList.toggle("error", Boolean(isError));
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
  }

  function debounce(fn, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  // ---- Data loading ----
  async function loadEmployees() {
    state.loading = true;
    state.error = null;
    renderTable();

    try {
      const params = new URLSearchParams({
        search: state.search,
        sortBy: state.sortBy,
        order: state.order,
      });
      const res = await fetch(`${API_BASE}?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to load employees.");
      const json = await res.json();
      state.employees = json.data;
    } catch (err) {
      state.error = err.message || "Something went wrong.";
    } finally {
      state.loading = false;
      renderTable();
    }
  }

  // ---- Rendering ----
  function renderTable() {
    headerCells.forEach((th) => {
      if (th.dataset.sort === state.sortBy) {
        th.setAttribute("aria-sort", state.order === "asc" ? "ascending" : "descending");
        const arrow = th.querySelector(".arrow");
        if (arrow) arrow.textContent = state.order === "asc" ? "↑" : "↓";
      } else {
        th.removeAttribute("aria-sort");
        const arrow = th.querySelector(".arrow");
        if (arrow) arrow.remove();
      }
    });

    if (state.loading) {
      tbody.innerHTML = "";
      tableStatus.innerHTML = `<div class="loading-state">Loading employees…</div>`;
      return;
    }

    if (state.error) {
      tbody.innerHTML = "";
      tableStatus.innerHTML = `<div class="error-state">${state.error}</div>`;
      return;
    }

    if (state.employees.length === 0) {
      tbody.innerHTML = "";
      tableStatus.innerHTML = `<div class="empty-state">No employees match your search.</div>`;
      return;
    }

    tableStatus.innerHTML = "";
    tbody.innerHTML = state.employees
      .map(
        (emp) => `
        <tr data-id="${emp.id}">
          <td class="name">${escapeHtml(emp.name)}</td>
          <td><span class="dept-badge">${escapeHtml(emp.department)}</span></td>
          <td>${escapeHtml(emp.role)}</td>
          <td class="salary">${money(emp.salary)}</td>
          <td>${emp.join_date}</td>
          <td>
            <div class="row-actions">
              <button class="btn btn-secondary btn-icon" data-action="edit" aria-label="Edit ${escapeHtml(emp.name)}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
              </button>
              <button class="btn btn-danger btn-icon" data-action="delete" aria-label="Delete ${escapeHtml(emp.name)}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>
              </button>
            </div>
          </td>
        </tr>`
      )
      .join("");
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  // ---- Search & sort ----
  searchInput.addEventListener(
    "input",
    debounce((e) => {
      state.search = e.target.value.trim();
      loadEmployees();
    }, 300)
  );

  headerCells.forEach((th) => {
    th.addEventListener("click", () => {
      const col = th.dataset.sort;
      if (state.sortBy === col) {
        state.order = state.order === "asc" ? "desc" : "asc";
      } else {
        state.sortBy = col;
        state.order = "asc";
      }
      loadEmployees();
    });
  });

  // ---- Add / Edit modal ----
  function openModal(employee) {
    form.reset();
    clearFieldErrors();

    if (employee) {
      modalTitle.textContent = "Edit Employee";
      employeeIdField.value = employee.id;
      document.getElementById("field-name").value = employee.name;
      document.getElementById("field-department").value = employee.department;
      document.getElementById("field-role").value = employee.role;
      document.getElementById("field-salary").value = employee.salary;
      document.getElementById("field-join-date").value = employee.join_date;
    } else {
      modalTitle.textContent = "Add Employee";
      employeeIdField.value = "";
    }

    modalOverlay.classList.add("open");
    document.getElementById("field-name").focus();
  }

  function closeModal() {
    modalOverlay.classList.remove("open");
  }

  function clearFieldErrors() {
    document.querySelectorAll(".field-error").forEach((el) => (el.textContent = ""));
  }

  addBtn.addEventListener("click", () => openModal(null));
  cancelFormBtn.addEventListener("click", closeModal);
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) closeModal();
  });

  tbody.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const row = btn.closest("tr");
    const id = Number(row.dataset.id);
    const employee = state.employees.find((emp) => emp.id === id);

    if (btn.dataset.action === "edit") {
      openModal(employee);
    } else if (btn.dataset.action === "delete") {
      openDeleteConfirm(employee);
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearFieldErrors();

    const payload = {
      name: document.getElementById("field-name").value.trim(),
      department: document.getElementById("field-department").value,
      role: document.getElementById("field-role").value.trim(),
      salary: Number(document.getElementById("field-salary").value),
      join_date: document.getElementById("field-join-date").value,
    };

    const id = employeeIdField.value;
    const isEdit = Boolean(id);

    try {
      const res = await fetch(isEdit ? `${API_BASE}/${id}` : API_BASE, {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const json = await res.json();

      if (!res.ok) {
        showToast(json.error || "Could not save employee.", true);
        return;
      }

      closeModal();
      showToast(isEdit ? "Employee updated." : "Employee added.");
      loadEmployees();
    } catch (err) {
      showToast("Network error — please try again.", true);
    }
  });

  // ---- Delete confirmation ----
  function openDeleteConfirm(employee) {
    pendingDeleteId = employee.id;
    confirmPreview.textContent = `${employee.name} — ${employee.role}, ${employee.department}`;
    confirmOverlay.classList.add("open");
  }

  function closeDeleteConfirm() {
    confirmOverlay.classList.remove("open");
    pendingDeleteId = null;
  }

  cancelDeleteBtn.addEventListener("click", closeDeleteConfirm);
  confirmOverlay.addEventListener("click", (e) => {
    if (e.target === confirmOverlay) closeDeleteConfirm();
  });

  confirmDeleteBtn.addEventListener("click", async () => {
    if (!pendingDeleteId) return;

    try {
      const res = await fetch(`${API_BASE}/${pendingDeleteId}`, { method: "DELETE" });
      const json = await res.json();

      if (!res.ok) {
        showToast(json.error || "Could not delete employee.", true);
        return;
      }

      showToast("Employee deleted.");
      closeDeleteConfirm();
      loadEmployees();
    } catch (err) {
      showToast("Network error — please try again.", true);
    }
  });

  // ---- Init ----
  loadEmployees();
})();
