// routes/employees.js
// REST API for employee records: GET (list w/ search+sort), GET one,
// POST, PUT, DELETE. Basic input validation on writes.

const express = require("express");
const db = require("../db/database");

const router = express.Router();

const ALLOWED_SORT_COLUMNS = ["name", "department", "role", "salary", "join_date"];

function validateEmployeePayload(body, { partial = false } = {}) {
  const errors = [];
  const { name, department, role, salary, join_date } = body;

  if (!partial || name !== undefined) {
    if (!name || typeof name !== "string" || !name.trim()) {
      errors.push("name is required.");
    }
  }
  if (!partial || department !== undefined) {
    if (!department || typeof department !== "string" || !department.trim()) {
      errors.push("department is required.");
    }
  }
  if (!partial || role !== undefined) {
    if (!role || typeof role !== "string" || !role.trim()) {
      errors.push("role is required.");
    }
  }
  if (!partial || salary !== undefined) {
    if (salary === undefined || salary === null || Number.isNaN(Number(salary)) || Number(salary) < 0) {
      errors.push("salary must be a non-negative number.");
    }
  }
  if (!partial || join_date !== undefined) {
    if (!join_date || !/^\d{4}-\d{2}-\d{2}$/.test(join_date)) {
      errors.push("join_date must be a valid date (YYYY-MM-DD).");
    }
  }

  return errors;
}

/**
 * GET /api/employees?search=&sortBy=&order=
 * Searchable (name/department/role) and sortable list.
 */
router.get("/", (req, res) => {
  const { search = "", sortBy = "name", order = "asc" } = req.query;

  const column = ALLOWED_SORT_COLUMNS.includes(sortBy) ? sortBy : "name";
  const direction = order.toLowerCase() === "desc" ? "DESC" : "ASC";

  const rows = db
    .prepare(
      `SELECT * FROM employees
       WHERE name LIKE ? OR department LIKE ? OR role LIKE ?
       ORDER BY ${column} ${direction}`
    )
    .all(`%${search}%`, `%${search}%`, `%${search}%`);

  res.json({ data: rows, count: rows.length });
});

/** GET /api/employees/:id */
router.get("/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Employee not found." });
  res.json({ data: row });
});

/** POST /api/employees */
router.post("/", (req, res) => {
  const errors = validateEmployeePayload(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });

  const { name, department, role, salary, join_date } = req.body;

  const result = db
    .prepare(
      `INSERT INTO employees (name, department, role, salary, join_date)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(name.trim(), department.trim(), role.trim(), Number(salary), join_date);

  const created = db.prepare("SELECT * FROM employees WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json({ data: created });
});

/** PUT /api/employees/:id */
router.put("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Employee not found." });

  const errors = validateEmployeePayload(req.body);
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });

  const { name, department, role, salary, join_date } = req.body;

  db.prepare(
    `UPDATE employees
     SET name = ?, department = ?, role = ?, salary = ?, join_date = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(name.trim(), department.trim(), role.trim(), Number(salary), join_date, req.params.id);

  const updated = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  res.json({ data: updated });
});

/** DELETE /api/employees/:id */
router.delete("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM employees WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Employee not found." });

  db.prepare("DELETE FROM employees WHERE id = ?").run(req.params.id);
  res.json({ data: existing, message: "Employee deleted." });
});

module.exports = router;
