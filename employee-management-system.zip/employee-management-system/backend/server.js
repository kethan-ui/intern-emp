// server.js
// Express server: mounts the employees REST API and serves the
// static frontend so the whole app runs from a single `npm start`.

const path = require("path");
const express = require("express");
const cors = require("cors");
const employeesRouter = require("./routes/employees");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// API routes
app.use("/api/employees", employeesRouter);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Serve the frontend (so you can open http://localhost:4000 directly)
const frontendPath = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendPath));

app.use((req, res, next) => {
  if (req.method !== "GET" || req.path.startsWith("/api")) return next();
  res.sendFile(path.join(frontendPath, "index.html"));
});

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`Employee Management System running at http://localhost:${PORT}`);
});
