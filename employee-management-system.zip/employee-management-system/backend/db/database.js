// db/database.js
// Initializes a file-based SQLite database with the employees table.
// Uses better-sqlite3 (synchronous API — simplest for a small REST API).

const path = require("path");
const Database = require("better-sqlite3");

const DB_PATH = path.join(__dirname, "..", "data", "employees.db");
const db = new Database(DB_PATH);

db.pragma("journal_mode = WAL");

// ---- Schema ----
db.exec(`
  CREATE TABLE IF NOT EXISTS employees (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    department  TEXT NOT NULL,
    role        TEXT NOT NULL,
    salary      REAL NOT NULL,
    join_date   TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// ---- Seed data (only if table is empty) ----
const count = db.prepare("SELECT COUNT(*) AS n FROM employees").get().n;

if (count === 0) {
  const insert = db.prepare(`
    INSERT INTO employees (name, department, role, salary, join_date)
    VALUES (@name, @department, @role, @salary, @join_date)
  `);

  const seed = [
    { name: "Ava Thompson", department: "Engineering", role: "Frontend Developer", salary: 78000, join_date: "2023-02-14" },
    { name: "Marcus Lee", department: "Engineering", role: "Backend Developer", salary: 84000, join_date: "2022-11-01" },
    { name: "Priya Nair", department: "HR", role: "HR Manager", salary: 71000, join_date: "2021-06-10" },
    { name: "Diego Alvarez", department: "Sales", role: "Account Executive", salary: 65000, join_date: "2023-09-05" },
    { name: "Hana Suzuki", department: "Design", role: "Product Designer", salary: 76000, join_date: "2022-04-22" },
    { name: "Owen Baxter", department: "Finance", role: "Financial Analyst", salary: 69000, join_date: "2024-01-15" },
  ];

  const insertMany = db.transaction((rows) => {
    for (const row of rows) insert.run(row);
  });

  insertMany(seed);
}

module.exports = db;
